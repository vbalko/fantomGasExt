# fantomGasExt
Chrome Extension showing GAS price on fantom network
